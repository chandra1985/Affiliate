<?php

return [
    'error-404' => 'Erro 404',
    'error-404-info' => 'Esta página não existe !',
    'button' => 'Home',
    'error-403' => 'Erro 403',
    'error-403-info' => 'Esta ação não é autorizado.',
    'error-503' => 'Erro 503',
    'error-503-info' => 'Volto logo.',
];

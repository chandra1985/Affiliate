<?php

return [
    'send' => 'Enviar'
];

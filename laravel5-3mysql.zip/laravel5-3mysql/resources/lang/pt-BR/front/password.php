<?php

return [
    'title' => 'Esqueci minha senha',
    'info'  => 'Você esqueceu sua senha, fique calmo ! Você pode criar uma nova. Mas para sua própria segurança nós queremos ter certeza de sua identificação. Então envie um email para nós preenchendo este formulário. Você vai receber uma mensagem com instruções para criar uma nova senha.',
    'email' => 'Seu email',
    'title-reset' => 'Criação de senha',
    'reset-info' => 'Para criar um anova senha, por favor preencha este formulário :',
    'password' => 'Sua senha',
    'confirm-password' => 'Confirme sua senha',
    'warning' => 'Aviso',
    'warning-password' => 'Ao menos 8 caracteres',
    'reset' => 'Lembrete de senha',
    'email-intro' => 'Você está recebendo este e-mail porque recebemos um pedido de redefinição de senha para a sua conta.',
    'email-click' => 'Clique no botão abaixo para redefinir sua senha :',
    'email-button' => 'Trocar a senha',
    'email-end' => 'Se não solicitar uma nova senha, é necessário nenhuma ação adiciona.',
];

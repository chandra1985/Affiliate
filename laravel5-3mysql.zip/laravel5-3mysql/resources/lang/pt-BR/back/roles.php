<?php

return [
    'dashboard' => 'Gestão de Papéis (cargos)',
    'roles' => 'Papéis',
    'admin' => 'Título para administradores',
    'redac' => 'Título para redatores',
    'user' => 'Título para usuários',
    'ok' => 'Papéis atualizados.'
];

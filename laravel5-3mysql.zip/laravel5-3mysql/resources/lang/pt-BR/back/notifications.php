<?php

return [
    'notifications' => 'Notificações',
    'new-notifications' => "Novas notificações",
    'post' => "Postar",
    'date' => "Data",
    'valid' => "Válido",
    'erase' => "Apagar",
];
<?php

return [
    'notifications' => 'Notifications',
    'new-notifications' => "New notifications",
    'post' => "Post",
    'date' => "Date",
    'valid' => "Valid",
    'erase' => "Erase",
];

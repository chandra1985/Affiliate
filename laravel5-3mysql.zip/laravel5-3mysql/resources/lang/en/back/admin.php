<?php

return [
    'administration' => 'Administration',
    'redaction' => 'Redaction',
    'home' => 'Back on site',
    'logout' => 'Logout',
    'dashboard' => 'Dashboard',
    'users' => 'users',
    'see-all' => 'See all',
    'add' => 'Add',
    'messages' => 'Messages',
    'comments' => 'Comments',
    'medias' => 'Medias',
    'posts' => 'Posts',
    'new-messages' => 'New messages !',
    'new-registers' => 'New users !',
    'new-posts' => 'New posts !',
    'new-comments' => 'New comments !',
    'blog-report' => 'Blog Report'
];

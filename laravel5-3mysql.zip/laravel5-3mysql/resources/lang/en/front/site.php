<?php

return [
    'title' => 'Laravel 5',
    'sub-title' => 'An awesome PHP framework',
    'home' => 'Home',
    'contact' => 'Contact',
    'blog' => 'Blog',
    'register' => 'Register',
    'forget-password' => 'Forgotten password',
    'connection' => 'Connection',
    'administration' => 'Administration',
    'redaction' => 'Redaction',
    'logout' => 'Logout',
    'notification-endtext' => 'If you’re having trouble clicking the button, copy and paste the URL below into your web browser:',
    'salutation' => 'Regards',
    'yes' => 'Yes',
    'no' => 'No',
];

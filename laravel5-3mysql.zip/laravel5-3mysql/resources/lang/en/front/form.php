<?php

return [
    'send' => 'Send'
];

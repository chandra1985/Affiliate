<?php

return [
    'error-404' => 'Erreur 404',
    'error-404-info' => 'La page que vous demandez n\'existe pas !',
    'button' => 'Accueil du site',
    'error-403' => 'Erreur 403',
    'error-403-info' => 'Cette action n\'est pas autorisée',
    'error-503' => 'Erreur 303',
    'error-503-info' => 'Le serveur est momentanément indisponible.',
];

<?php

return [
    'send' => 'Envoyer'
];

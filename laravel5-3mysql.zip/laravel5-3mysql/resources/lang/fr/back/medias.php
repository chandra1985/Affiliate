<?php

return [
    'dashboard' => 'Gestion des médias',
    'medias' => 'Médias'
];

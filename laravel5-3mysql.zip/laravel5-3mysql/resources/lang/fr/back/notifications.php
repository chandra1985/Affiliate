<?php

return [
    'notifications' => 'Notifications',
    'new-notifications' => "Nouvelles notifications",
    'post' => "Article",
    'date' => "Date",
    'valid' => "Valide",
    'erase' => "Effacer",
];
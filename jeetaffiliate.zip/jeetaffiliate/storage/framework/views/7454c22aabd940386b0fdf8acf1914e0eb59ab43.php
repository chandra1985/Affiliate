<?php $__env->startSection('title', 'Flipkart Category'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Flipkart Category</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="box">
    <div class="box-header">
                                            
    </div><!-- /.box-header -->
    <div class="box-body table-responsive">
        <table id="category_listing" class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Version</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($value['cat_api_name']); ?></td>
                    <td><?php echo e($value['cat_version']); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!--    <script> alert('hi'); </script>-->
<script>
    $(function() {
        $('#category_listing').DataTable({
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": true
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('css'); ?>

<?php $__env->startPush('js'); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('admin/home', 'Admin\AdminhomeController@index');
Route::get('admin/fkcategory', 'Admin\FkcategoryController@index');

Route::get('admin/tasks', 'Admin\TasksController@create');
Route::get('admin/saveproduct', 'Admin\TasksController@saveproduct');
Route::get('admin/fksaveofferproduct', 'Admin\TasksController@fksaveofferproduct');
Route::group(['prefix' => 'api/v1'], function(){
	Route::resource('jokes', 'JokesController');
});


Route::group(['prefix' => 'api/v1'], function()
{
    Route::resource('authenticate', 'AuthenticateController', ['only' => ['index']]);
    Route::post('authenticate', 'AuthenticateController@authenticate');
    Route::get('authenticate/user', 'AuthenticateController@getAuthenticatedUser');
});
/*
Route::group(['prefix' => 'api/v1.1'], function()
{
Route::get('jeetfkallproduct', 'Webservices\JeetfkwebservicesController@allfkproduct');
});
 * 
 */




Auth::routes();



<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('admin/tasks', 'Admin\TasksController@create');
Route::get('admin/saveproduct', 'Admin\TasksController@saveproduct');
Route::group(['prefix' => 'api/v1'], function(){
	Route::resource('jokes', 'JokesController');
});


Route::group(['prefix' => 'api/v1'], function()
{
    Route::resource('authenticate', 'AuthenticateController', ['only' => ['index']]);
    Route::post('authenticate', 'AuthenticateController@authenticate');
    Route::get('authenticate/user', 'AuthenticateController@getAuthenticatedUser');
});

Route::group(['prefix' => 'api/v1.1'], function()
{
Route::get('jeetfkallproduct', 'Webservices\JeetfkwebservicesController@allfkproduct');
});


//token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOjIsImlzcyI6Imh0dHA6XC9cL2plZXQuYWZmaWxpYXRlXC9hcGlcL3YxXC9hdXRoZW50aWNhdGUiLCJpYXQiOjE0NzQ3NzY3MjksImV4cCI6MTQ3NDc4MDMyOSwibmJmIjoxNDc0Nzc2NzI5LCJqdGkiOiI4NDE0NzQ5NzY4NzU5ZTVjYWVlMzM0ODYzZmNkNWIyZiJ9.f2WJcS9K0ElwfLrBx6Naqc2BUpWNN84i_Fc1oFBVKrI



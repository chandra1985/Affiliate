<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Jeetfkoffer extends Model
{
    protected $table = 'fk_offer';
        public function Jeetfkofferimages() {
        return $this->hasMany('App\Model\Jeetfkofferimages','offer_id');
    }
}

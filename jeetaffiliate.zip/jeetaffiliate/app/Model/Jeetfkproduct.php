<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Jeetfkproduct extends Model {

    protected $table = 'fk_product';

    public function jeetproductimage() {
        return $this->hasMany('App\Model\Jeetproductimage','jeet_id');
    }
    
    public function jeeproductkeyspecs() {
        return $this->hasMany('App\Model\Jeeproductkeyspecs','jeet_id');
    }

}

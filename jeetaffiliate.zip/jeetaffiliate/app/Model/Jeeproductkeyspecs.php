<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Jeeproductkeyspecs extends Model
{
    protected $table = 'fk_product_key_specs';
}

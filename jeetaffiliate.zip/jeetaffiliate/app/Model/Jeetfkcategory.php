<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Jeetfkcategory extends Model
{
     protected $table = 'fk_category';
}

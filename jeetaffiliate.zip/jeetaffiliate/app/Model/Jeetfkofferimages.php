<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Jeetfkofferimages extends Model
{
    protected $table = 'fk_offer_images';
}

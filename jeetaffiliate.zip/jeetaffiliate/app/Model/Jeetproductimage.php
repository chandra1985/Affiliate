<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Jeetproductimage extends Model {

    protected $table = 'fk_product_images';

//    public function jeetfkproduct() {
//        return $this->hasMany('App\Model\Jeetfkproduct','id','id');
//    }

}

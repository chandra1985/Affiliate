<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use GuzzleHttp\Client as GuzzleHttpClient;
use GuzzleHttp\Exception\RequestException;

class TasksController extends Controller {

    public function create() {

        try {

            $client = new GuzzleHttpClient();
            $res = $client->request('GET', 'https://affiliate-api.flipkart.net/affiliate/api/jeetchakk.json', [
                'auth' => ['', '']
            ]);
            //$client->request('GET', '/get', ['headers' => ['X-Foo' => 'test']);
            //$client->request('GET', 'http://httpbin.org?foo=bar'); //query strin paramete
            $status = $res->getStatusCode(); //200 success
if($status==200){
            $res->getHeader('content-type');
// 'application/json; charset=utf8'
//echo $res->getBody();
            $data = json_decode($res->getBody(), TRUE);

            $allCat = $data['apiGroups']['affiliate']['apiListings'];

            foreach ($allCat as $key => $value) {
                $apiName = $value['apiName'];
                foreach ($value['availableVariants'] as $keyvarient => $valuevarient) {
                    $version = $keyvarient;
                    $resourceName = $valuevarient['resourceName'];
                    $delete = $valuevarient['delete'];
                    $post = $valuevarient['post'];
                    $put = $valuevarient['put'];
                    $get = $valuevarient['get'];
                    $deltaGet = $valuevarient['deltaGet'];
                    $top = $valuevarient['top'];
                    if ($version == 'v1.1.0') {
                        DB::table('fk_category_temp')->insert([
                            ['cat_api_name' => $apiName,
                                'cat_version' => $version,
                                'cat_resource_name' => $resourceName,
                                'cat_delete' => $delete,
                                'cat_post' => $post,
                                'cat_put' => $put,
                                'cat_get' => $get,
                                'cat_delta_get' => $deltaGet,
                                'cat_top' => $top
                            ]
                        ]);
                    }
                }
            }
        }
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }


        die;
    }

    public function saveproduct() {
        die;
        //DB::statement('drop table userstemp');
   
        $category = DB::table('fk_category_temp')
                ->select(DB::raw('*'))
                ->where('cat_resource_name', '=', 'mobiles')
                ->where('status', '=', '0')
                ->get();
        
        try {
            foreach ($category as $catvalue) {
                $categoryName = $catvalue->cat_api_name;
                $productGetUrl = $catvalue->cat_get;


                $client = new GuzzleHttpClient();
                $res = $client->request('GET', $productGetUrl . '&inStock=true', [
                    'headers' => ['Fk-Affiliate-Id' => 'jeetchakk', 'Fk-Affiliate-Token' => 'e7c3cdfd4e694abab1c3b0d08c0067de']
                ]);
                //$client->request('GET', '/get', ['headers' => ['X-Foo' => 'test']);
                //$client->request('GET', 'http://httpbin.org?foo=bar'); //query strin paramete
               $status = $res->getStatusCode(); //200 success
              if($status==200){
                $res->getHeader('content-type');
                // 'application/json; charset=utf8'
                $data = json_decode($res->getBody(), TRUE);

                $milliseconds = $data['validTill'];
                $seconds = $milliseconds / 1000;
                $expireAt = date("Y-m-d H:i:s", $seconds);


                 echo count($data['productInfoList']);
                foreach ($data['productInfoList'] as $key => $productValy) {
                    $productId = $productValy['productBaseInfoV1']['productId'];
                    echo $productId."<br><hr>";
                    $title = $productValy['productBaseInfoV1']['title'];

                    $categoryPath = $productValy['productBaseInfoV1']['categoryPath'];

                    $maximumRetailPriceAmount = $productValy['productBaseInfoV1']['maximumRetailPrice']['amount'];
                    $maximumRetailPriceCurrency = $productValy['productBaseInfoV1']['maximumRetailPrice']['currency'];

                    $flipkartSellingPriceAmount = $productValy['productBaseInfoV1']['flipkartSellingPrice']['amount'];
                    $flipkartSellingPriceCurrency = $productValy['productBaseInfoV1']['flipkartSellingPrice']['currency'];

                    $flipkartSpecialPriceAmount = $productValy['productBaseInfoV1']['flipkartSpecialPrice']['amount'];
                    $flipkartSpecialPriceCurrency = $productValy['productBaseInfoV1']['flipkartSpecialPrice']['currency'];

                    $productUrl = $productValy['productBaseInfoV1']['productUrl'];

                    $productDescription = $productValy['productBaseInfoV1']['productDescription'];

                    $productBrand = $productValy['productBaseInfoV1']['productBrand'];

                    $inStock = $productValy['productBaseInfoV1']['inStock'];
                    //isAvailable not found

                    $codAvailable = $productValy['productBaseInfoV1']['codAvailable'];

                    $discountPercentage = $productValy['productBaseInfoV1']['discountPercentage'];

                    $size = $productValy['productBaseInfoV1']['attributes']['size'];
                    $color = $productValy['productBaseInfoV1']['attributes']['color'];
                    $storage = $productValy['productBaseInfoV1']['attributes']['storage'];
                    $sizeUnit = $productValy['productBaseInfoV1']['attributes']['sizeUnit'];
                    $displaySize = $productValy['productBaseInfoV1']['attributes']['displaySize'];
                    //Offset not found
                    //shipping section start 

                    $shippingChargesAmount = $productValy['productShippingInfoV1']['shippingCharges']['amount'];
                    $shippingChargesCurrency = $productValy['productShippingInfoV1']['shippingCharges']['currency'];

                    $sellerName = $productValy['productShippingInfoV1']['sellerName'];

                    $sellerAverageRating = $productValy['productShippingInfoV1']['sellerAverageRating'];

                    $sellerNoOfRatings = $productValy['productShippingInfoV1']['sellerNoOfRatings'];

                    $sellerNoOfReviews = $productValy['productShippingInfoV1']['sellerNoOfReviews'];

                    /* +++++++++++++++++++++++++++++++Inser data in product table++++++++++++++++++++ */
                    $jeetproductid = DB::table('fk_product_temp')->insertGetId(
                            ['product_category' => $categoryName,
                                'product_id' => $productId,
                                'product_title' => $title,
                                'product_category_path' => $categoryPath,
                                'product_mrp_amount' => $maximumRetailPriceAmount,
                                'product_mrp_currency' => $maximumRetailPriceCurrency,
                                'product_fsp_amount' => $flipkartSellingPriceAmount,
                                'product_fsp_currency' => $flipkartSellingPriceCurrency,
                                'product_fspecialp_amount' => $flipkartSpecialPriceAmount,
                                'product_fspecialp_currency' => $flipkartSpecialPriceCurrency,
                                'product_url' => $productUrl,
                                'product_description' => $productDescription,
                                'product_brand' => $productBrand,
                                'product_instock' => $inStock,
                                'product_cod_available' => $codAvailable,
                                'product_discount_percentage' => $discountPercentage,
                                'product_size' => $size,
                                'product_color' => $color,
                                'product_storage' => $storage,
                                'product_sizeUnit' => $sizeUnit,
                                'product_displaySize' => $displaySize,
                                'product_shipping_amount' => $shippingChargesAmount,
                                'product_shipping_currency' => $shippingChargesCurrency,
                                'product_seller_name' => $sellerName,
                                'product_seller_avgrating' => $sellerAverageRating,
                                'product_seller_noofrating' => $sellerNoOfRatings,
                                'product_sellernoofreviews' => $sellerNoOfReviews,
                                'product_expire_at' => $expireAt]
                    );
                    /* +++++++++++++++++++++++++++++++Inser data in product image table++++++++++++++++++++ */
                    $imageUrlsArray = $productValy['productBaseInfoV1']['imageUrls'];
                    
                    $dataImage = array();
                    if (count($imageUrlsArray) > 0) {
                        foreach ($imageUrlsArray as $imagekey => $imagevalue) {
                            
                            $dataImage[] = array('jeet_id' => $jeetproductid,
                                                 'product_id' => $productId,
                                                 'product_image_url' => $imagevalue);
                        }

                        DB::table('fk_product_images_temp')->insert($dataImage);
                    }
                    /* +++++++++++++++++++++++++++++++Inser data in product offer table++++++++++++++++++++ */
                    $offersArray = $productValy['productBaseInfoV1']['offers'];
                    $dataoffer = array();
                    if (count($offersArray) > 0) {
                        foreach ($offersArray as $orrerkey => $offervalue) {
                            $dataoffer[]= array('jeet_id' => $jeetproductid,
                                                'product_id' => $productId,
                                                'product_offer' => $offervalue);
                        }
                        DB::table('fk_product_offer_temp')->insert($dataoffer);
                    }
                    //Category specification start 
                    /* +++++++++++++++++++++++++++++++Inser data in product keySpecs table++++++++++++++++++++ */
                    $keySpecsArray = $productValy['categorySpecificInfoV1']['keySpecs'];
                    if (count($keySpecsArray) > 0) {
                        $dataKeySpec = array();
                        foreach ($keySpecsArray as $keySpecsVal) {
                            $dataKeySpec[] = array('jeet_id' => $jeetproductid,
                                'product_id' => $productId,
                                'key_specs_value' => $keySpecsVal);
                        }
                         DB::table('fk_product_key_specs_temp')->insert($dataKeySpec);
                    }

                    /* +++++++++++++++++++++++++++++++Inser data in product Detail Specs table++++++++++++++++++++ */

                    $detailedSpecsArray = $productValy['categorySpecificInfoV1']['detailedSpecs'];
                    if (count($detailedSpecsArray) > 0) {
                        $dataDetaiKeySpec = array();
                        foreach ($detailedSpecsArray as $detailSpecsVal) {
                            $dataDetaiKeySpec[]= array('jeet_id' => $jeetproductid,
                                'product_id' => $productId,
                                'detailed_specs_value' => $detailSpecsVal);
                        }
                        DB::table('fk_product_detailed_specs_temp')->insert($dataDetaiKeySpec);
                    }

                    $specificationListArray = $productValy['categorySpecificInfoV1']['specificationList'];
                    if (count($specificationListArray) > 0) {
                        foreach ($specificationListArray as $keyspec => $valueSpecification) {

                            $specificationCatName = $valueSpecification['key'];
                            foreach ($valueSpecification['values'] as $valueSpeVal) {
                                $specificationSubCatName = $valueSpeVal['key'];
                                $dataListP = array();
                                foreach ($valueSpeVal['value'] as $valueFinalSpe) {
                                    $dataListP[] = array('jeet_id' => $jeetproductid,
                                        'product_id' => $productId,
                                        'specification_category' => $specificationCatName,
                                        'specification_sub_category' => $specificationSubCatName,
                                        'specification_value' => $valueFinalSpe);
                                }
                                DB::table('fk_product_specification_list_temp')->insert($dataListP);
                            }
                        }
                    }
                    /* +++++++++++++++++++++++++++++++Inser data in product books info table++++++++++++++++++++ */
                    $booksInfoArray = $productValy['categorySpecificInfoV1']['booksInfo'];
                    $language = $booksInfoArray['language'];
                    $binding = $booksInfoArray['binding'];
                    $pages = $booksInfoArray['pages'];
                    $publisher = $booksInfoArray['publisher'];
                    $year = $booksInfoArray['year'];
                    if ($language != '') {
                        DB::table('fk_product_bookinfo_temp')->insert([
                            'jeet_id' => $jeetproductid,
                            'product_id' => $productId,
                            'book_key' => 'language',
                            'book_value' => $language
                        ]);
                    }

                    if ($binding != '') {
                        DB::table('fk_product_bookinfo_temp')->insert([
                            'jeet_id' => $jeetproductid,
                            'product_id' => $productId,
                            'book_key' => 'binding',
                            'book_value' => $binding
                        ]);
                    }

                    if ($pages != '') {
                        DB::table('fk_product_bookinfo_temp')->insert([
                            'jeet_id' => $jeetproductid,
                            'product_id' => $productId,
                            'book_key' => 'pages',
                            'book_value' => $pages
                        ]);
                    }

                    if ($publisher != '') {
                        DB::table('fk_product_bookinfo_temp')->insert([
                            'jeet_id' => $jeetproductid,
                            'product_id' => $productId,
                            'book_key' => 'publisher',
                            'book_value' => $publisher
                        ]);
                    }

                    if ($year != '') {
                        DB::table('fk_product_bookinfo_temp')->insert([
                            'jeet_id' => $jeetproductid,
                            'product_id' => $productId,
                            'book_key' => 'year',
                            'book_value' => $year
                        ]);
                    }

                    /* +++++++++++++++++++++++++++++++Inser data in product lifestyle table++++++++++++++++++++ */
                    $lifeStyleInfoArray = $productValy['categorySpecificInfoV1']['lifeStyleInfo'];
                    if (strlen(implode($lifeStyleInfoArray)) != 0) {

                        $sleeve = $lifeStyleInfoArray['sleeve'];
                        $neck = $lifeStyleInfoArray['neck'];
                        $idealFor = $lifeStyleInfoArray['sleeve'];
                        DB::table('fk_product_lifestyleinfo_temp')->insert([
                            'jeet_id' => $jeetproductid,
                            'product_id' => $productId,
                            'sleeve' => $sleeve,
                            'neck' => $neck,
                            'idealFor' => $idealFor
                        ]);
                    }
                }
            }
            }
        } catch (Exception $e) {
            echo 'Message: ' . $e->getMessage();
        }


        die;
    }

    public function fksaveofferproduct() {
die;
        $client = new GuzzleHttpClient();
        $res = $client->request('GET', 'https://affiliate-api.flipkart.net/affiliate/offers/v1/all/json', [
            'headers' => ['Fk-Affiliate-Id' => 'jeetchakk', 'Fk-Affiliate-Token' => 'e7c3cdfd4e694abab1c3b0d08c0067de']
        ]);
        $status = $res->getStatusCode(); //200 success
        if($status==200){
        $res->getHeader('content-type');
        $data = json_decode($res->getBody(), TRUE);
        $allOfferProduct = $data['allOffersList'];
        foreach ($allOfferProduct as $key => $value) {
            $millisecondsStartTime = $value['startTime'];
            $secondsStartTime = $millisecondsStartTime / 1000;
            $startTime = date("Y-m-d H:i:s", $secondsStartTime);
            $millisecondsEndTime = $value['endTime'];
            $secondsEndTime = $millisecondsEndTime / 1000;
            $endTime = date("Y-m-d H:i:s", $secondsEndTime);
            $title = $value['title'];
            $description = $value['description'];
            $url = $value['url'];
            $category = $value['category'];
            $availability = $value['availability'];
            $imageUrls = $value['imageUrls'];


            /* +++++++++++++++++++++++++++++++Inser data in offer table++++++++++++++++++++ */
            $offerid = DB::table('fk_offer_temp')->insertGetId(
                    ['offer_startTime' => $startTime,
                        'offer_endTime' => $endTime,
                        'offer_title' => $title,
                        'offer_description' => $description,
                        'offer_url' => $url,
                        'offer_category' => $category,
                        'offer_availability' => $availability]
            );
            /* +++++++++++++++++++++++++++++++Inser data in offer image table++++++++++++++++++++ */
            if (count($imageUrls) > 0) {
                foreach ($imageUrls as $valueImage) {
                    $imgUrl = $valueImage['url'];
                    $resolutionType = $valueImage['resolutionType'];
                     DB::table('fk_offer_images_temp')->insert([
                                'offer_id' => $offerid,
                                'offer_image_url' => $imgUrl,
                                'image_resolutionType' => $resolutionType
                            ]);
                    
                    
                }
            }
        }
    }
        die;
    }

}


<?php

namespace App\Http\Controllers\Webservices;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Model\Jeetfkproduct;
use App\Model\Jeetproductimage;
use Response;

class JeetfkwebservicesController extends Controller {
    /*
      public function __construct() {
      $this->middleware('jwt.auth');
      }
     * 
     */

    public function allfkproduct(Request $request) {
        $search_term = $request->input('search');
        $limit = $request->input('limit') ? $request->input('limit') : 5;

        if ($search_term) {
            $allProduct = Jeetfkproduct::orderBy('id', 'DESC')->where('product_title', 'LIKE', "%$search_term%")->with(
                            array('Jeetproductimage' => function($query) {
                                    $query->select('product_image_url as Images', 'jeet_id');
                                })
                    )->select('product_category', 'product_id', 'product_title', 'id')->paginate($limit);

            $allProduct->appends(array(
                'search' => $search_term,
                'limit' => $limit
            ));
        } else {
            $allProduct = Jeetfkproduct::orderBy('id', 'DESC')->with(
                            array('Jeetproductimage' => function($query) {
                                    $query->select('product_image_url as Images', 'jeet_id');
                                })
                    )->select('product_category', 'product_id', 'product_title', 'id')->paginate($limit);

            $allProduct->appends(array(
                'limit' => $limit
            ));
        }
        // $allProduct = Jeetfkproduct::all();
        return Response::json($this->transformCollection($allProduct), 200);
    }

    private function transformCollection($data) {
        $dataArray = $data->toArray();
        return [
            'total' => $dataArray['total'],
            'per_page' => intval($dataArray['per_page']),
            'current_page' => $dataArray['current_page'],
            'last_page' => $dataArray['last_page'],
            'next_page_url' => $dataArray['next_page_url'],
            'prev_page_url' => $dataArray['prev_page_url'],
            'from' => $dataArray['from'],
            'to' => $dataArray['to'],
            'data' => array_map([$this, 'transform'], $dataArray['data'])
        ];
    }

    private function transform($data) {
        return [
            'productCategory' => $data['product_category'],
            'productId' => $data['product_id'],
            'productTitle' => $data['product_title'],
            'productImage' => $data['jeetproductimage']
        ];
    }

}

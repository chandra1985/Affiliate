<?php

namespace App\Http\Controllers\Webservices;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Model\Jeetfkproduct;
use Response;
use Illuminate\Support\Facades\DB;

class JeetfkwebservicesController extends Controller {
    /*
      public function __construct() {
      $this->middleware('jwt.auth');
      }
     * 
     */

    public function allfkproduct(Request $request) {
        $search_term = $request->input('search');
        $limit = $request->input('limit') ? $request->input('limit') : 5;

        if ($search_term) {
            $allProduct = Jeetfkproduct::orderBy('id', 'DESC')->where('product_category', 'LIKE', "%$search_term%")->with(
                            array('Jeetproductimage' => function($query) {
                                    $query->select('product_image_url as Image', 'jeet_id');
                                },'Jeeproductkeyspecs' => function($query) {
                                    $query->select('key_specs_value as KeySpecs', 'jeet_id');
                                })
                    )->select(DB::raw("CONCAT(product_mrp_amount,' ',product_mrp_currency)  AS mrp,
                            CONCAT(product_shipping_amount,' ',product_shipping_currency)  AS shipping"),
                            'product_category',
                            'product_id',
                            'product_title',
                            'id',
                            'product_url',
                            'product_brand',
                            'product_size',
                            'product_color',
                            'product_seller_avgrating',
                            'product_seller_noofrating',
                            'product_sellernoofreviews'
                            )->paginate($limit);

            $allProduct->appends(array(
                'search' => $search_term,
                'limit' => $limit
            ));
        } else {
            $allProduct = Jeetfkproduct::orderBy('id', 'DESC')->with(
                            array('Jeetproductimage' => function($query) {
                                    $query->select('product_image_url as Image', 'jeet_id');
                                },'Jeeproductkeyspecs' => function($query) {
                                    $query->select('key_specs_value as KeySpecs', 'jeet_id');
                                })
                               
                    )->select( 
                            DB::raw("CONCAT(product_mrp_amount,' ',product_mrp_currency)  AS mrp,
                                CONCAT(product_shipping_amount,' ',product_shipping_currency)  AS shipping"),
                            'product_category', 
                            'product_id', 
                            'product_title', 
                            'id',
                            'product_url',
                            'product_brand',
                            'product_size',
                            'product_color',
                            'product_seller_avgrating',
                            'product_seller_noofrating',
                            'product_sellernoofreviews'
                            )->paginate($limit);

            $allProduct->appends(array(
                'limit' => $limit
            ));
        }
        // $allProduct = Jeetfkproduct::all();
        return Response::json($this->transformCollection($allProduct), 200);
    }

    private function transformCollection($data) {
        $dataArray = $data->toArray();
        return [
            'total' => $dataArray['total'],
            'per_page' => intval($dataArray['per_page']),
            'current_page' => $dataArray['current_page'],
            'last_page' => $dataArray['last_page'],
            'next_page_url' => $dataArray['next_page_url'],
            'prev_page_url' => $dataArray['prev_page_url'],
            'from' => $dataArray['from'],
            'to' => $dataArray['to'],
            'data' => array_map([$this, 'transform'], $dataArray['data'])
        ];
    }

    private function transform($data) {
        return [
            'ProductCategory' => $data['product_category'],
            'ProductMRP' => $data['mrp'],
            'ProductURL' => $data['product_url'],
            'ProductBrand' => $data['product_brand'],
            'ProductColor' => $data['product_color'],
            'ProductSize' => $data['product_size'],
            'ProductShipping' => $data['shipping'],
            'ProductSellerAverageRating' => $data['product_seller_avgrating'],
            'ProductSellerNumberOfRating' => $data['product_seller_noofrating'],
            'ProductSellerReviews' => $data['product_sellernoofreviews'],
            'ProductId' => $data['product_id'],
            'ProductTitle' => $data['product_title'],
            'ProductImages' => $data['jeetproductimage'],
            'ProductKeySpecs' => $data['jeeproductkeyspecs']
        ];
    }

}

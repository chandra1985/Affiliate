<?php

namespace App\Http\Controllers\Webservices;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Model\Jeetfkoffer;
use Response;
use Illuminate\Support\Facades\DB;

class JeetapifkofferController extends Controller
{
        
 public function index(Request $request) {
     /*list all offer product with title search*/
     
        $search_term = $request->input('search');
        $limit = $request->input('limit') ? $request->input('limit') : 5;

        if ($search_term) {
            $allOffer = Jeetfkoffer::orderBy('id', 'DESC')->where('offer_title', 'LIKE', "%$search_term%")->with(
                            array('Jeetfkofferimages' => function($query) {
                                    $query->select('offer_image_url as Image','image_resolutionType as ImageResolution', 'offer_id');
                                })
                    )->select('offer_title',
                            'offer_description',
                            'offer_url',
                            'id',
                            'offer_category',
                            'offer_url'
                            )->paginate($limit);

            $allOffer->appends(array(
                'search' => $search_term,
                'limit' => $limit
            ));
        } else {
            $allOffer = Jeetfkoffer::orderBy('id', 'DESC')->with(
                            array('Jeetfkofferimages' => function($query) {
                                    $query->select('offer_image_url as Image','image_resolutionType as ImageResolution', 'offer_id');
                                })
                    )->select('offer_title',
                            'offer_description',
                            'offer_url',
                            'id',
                            'offer_category',
                            'offer_url'
                            )->paginate($limit);

            $allOffer->appends(array(
                'limit' => $limit
            ));
        }
       return Response::json($this->transformCollectionOffer($allOffer), 200);
    }
    
 private function transformCollectionOffer($data) {
        $dataArray = $data->toArray();
        return [
            'total' => $dataArray['total'],
            'per_page' => intval($dataArray['per_page']),
            'current_page' => $dataArray['current_page'],
            'last_page' => $dataArray['last_page'],
            'next_page_url' => $dataArray['next_page_url'],
            'prev_page_url' => $dataArray['prev_page_url'],
            'from' => $dataArray['from'],
            'to' => $dataArray['to'],
            'data' => array_map([$this, 'transformOffer'], $dataArray['data'])
        ];
    }

    private function transformOffer($data) {
        return [
            'OfferTitle' => $data['offer_title'],
            'OfferDescription' => $data['offer_description'],
            'OfferURL' => $data['offer_url'],
            'OfferCategory' => $data['offer_category'],
            'OfferImages' => $data['jeetfkofferimages']
            ];
    }
    

}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fk_product_image extends Model
{
    protected $table = 'fk_category';
}

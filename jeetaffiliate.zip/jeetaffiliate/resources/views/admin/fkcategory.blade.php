{{-- resources/views/admin/dashboard.blade.php --}}

@extends('adminlte::page')

@section('title', 'Flipkart Category')

@section('content_header')
<h1>Flipkart Category</h1>
@stop

@section('content')
<div class="box">
    <div class="box-header">
                                            
    </div><!-- /.box-header -->
    <div class="box-body table-responsive">
        <table id="category_listing" class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Version</th>
                </tr>
            </thead>
            <tbody>
                @foreach($category as $key=>$value)
                <tr>
                    <td>{{ $key+1 }}</td>
                    <td>{{ $value['cat_api_name'] }}</td>
                    <td>{{ $value['cat_version'] }}</td>
                </tr>
                @endforeach
        </table>
    </div>
</div>


@stop

@section('css')
<link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
<!--    <script> alert('hi'); </script>-->
<script>
    $(function() {
        $('#category_listing').DataTable({
            "paging": true,
            "lengthChange": true,
            "searching": true,
            "ordering": true,
            "info": true,
            "autoWidth": true
        });
    });
</script>
@stop
@push('css')

@push('js')